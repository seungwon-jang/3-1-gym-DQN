import rclpy
from rclpy.node import Node #노드 상속
from rclpy.action import ActionServer

from my_interfaces.msg import UID
from my_interfaces.srv import AddTwoInt
from my_interfaces.action import AddDigit

import time

class node1(Node):

    def __init__(self):
        super().__init__('node1') #노드 이름 정하기
        #string을 출력하는 큐가 10인 topic 만들기 - publisher
        self.publisher_ = self.create_publisher(UID, 'topic', 10)
        timer_period = 1  # 입력 주기seconds
        self.timer = self.create_timer(timer_period, self.timer_callback) #타이머 콜백 함수 지정
        #서비스 서버 설정
        self.srv = self.create_service(AddTwoInt, 'service', self.mul_callback)
        #파라미터 설정
        self.declare_parameter('topic_par', 2020741068)
        #액션 서버 설정
        self._action_server = ActionServer(
            self,
            AddDigit,
            'AddDigit',
            self.execute_callback)
        self.declare_parameter('my_uid', 2020741068)



    #타이머 콜백 함수
    def timer_callback(self):
        my_param = self.get_parameter('topic_par').get_parameter_value().integer_value

        my_new_param = rclpy.parameter.Parameter(
            'topic_par',
            #rclpy.Parameter.Type.UID,
            #2020741068
        )
        all_new_parameters = [my_new_param]
        self.set_parameters(all_new_parameters)

        msg = UID()
        msg.uid = my_param #파라미터 값 넣기
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%d"' % msg.uid)
     
    #서비스 관련 골벡 함수
    def mul_callback(self, request, response):
        response.sum = request.a * request.b
        self.get_logger().info('Incoming request\na: %d b: %d' % (request.a, request.b))

        return response
    #액션 실행 콜벡 함수
    def execute_callback(self, goal_handle):
        self.get_logger().info('Executing goal...')

        #파라미터 값을 가져와 초기 값으로 사용하기
        my_param = self.get_parameter('topic_par').get_parameter_value().integer_value
        
        feedback_msg = AddDigit.Feedback()
        feedback_msg.pre_resultid = goal_handle.request.uid + 1

        for i in range(1, 10):
            feedback_msg.pre_resultid += 1
            self.get_logger().info('Feedback: {0}'.format(feedback_msg.pre_resultid))
            goal_handle.publish_feedback(feedback_msg)
            time.sleep(1)

        goal_handle.succeed()

        result = AddDigit.Result()
        result.resultid = feedback_msg.pre_resultid
        return result


def main(args=None):
    rclpy.init(args=args)

    my_node1 = node1()

    rclpy.spin(my_node1)
    my_node1.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
