import sys
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from my_interfaces.msg import UID
from my_interfaces.srv import AddTwoInt
from my_interfaces.action import AddDigit
#다른 패키지에서 가져오는 것들

class Node2(Node):

    def __init__(self):
        super().__init__('node2') #노드 이름 정하기
        #subscriber 만들기, string을 받는 topic이다.
        self.subscription = self.create_subscription(
            UID,
            'topic',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        #서비스의 클라이언트 부분
        self.cli = self.create_client(AddTwoInt, 'service')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = AddTwoInt.Request()
        #액션의 클라이언트 파트
        self.action_client = ActionClient(self, AddDigit, 'AddDigit')
        #파라미터 설정
        self.declare_parameter('my_par', 2020741068)
        
        

    #massage data를 받는 콜벡 함수
    def listener_callback(self, msg):
        self.get_logger().info('I heard: "%s"' % msg.uid)
    #응답을 보내는 함수
    def send_request(self, a, b):
        self.req.a = a
        self.req.b = b
        self.future = self.cli.call_async(self.req)
        rclpy.spin_until_future_complete(self, self.future)
        return self.future.result()
    
    #액션 클라이언트 파트의 함수들
    #액션 서버가 사용가능 할때까지 기다리고, 사용가능하면, 서버로 goal을 보낸다
    def send_goal(self, uid):
        self.get_logger().info('send_goal() called')

        self.action_client.wait_for_server(10)

        my_param = uid

        goal_msg = AddDigit.Goal()
        goal_msg.uid = my_param

        self._send_goal_future = self.action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback)

        self._send_goal_future.add_done_callback(self.goal_response_callback)
    #리스폰스 콜벡 함수
    def goal_response_callback(self, future):
        goal_handle = future.result()

        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self.get_logger().info('Goal accepted :)')

        self._get_result_future = goal_handle.get_result_async()

        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Result: {0}'.format(result.resultid))

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info('Received feedback: {0}'.format(feedback.pre_resultid))
   


def main(args=None):
    rclpy.init(args=args)

    my_node2 = Node2()
    #파라이터 값 받기
    my_param = my_node2.get_parameter('my_par').get_parameter_value().integer_value

    my_new_param = rclpy.parameter.Parameter(
            'my_par',
            rclpy.Parameter.Type.INTEGER,
            my_param
    )

    all_new_parameters = [my_new_param]
    my_node2.set_parameters(all_new_parameters)

    my_node2.send_goal(my_param)

    #서비스 반환 파트
    response = my_node2.send_request(int(sys.argv[1]), int(sys.argv[2]))
    my_node2.get_logger().info(
        'Result of add_two_ints: for %d * %d = %d' %
        (int(sys.argv[1]), int(sys.argv[2]), response.sum))

    #노드 2 반복해서 돌리기
    rclpy.spin(my_node2)
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    my_node2.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
